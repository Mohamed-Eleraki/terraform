import json
import boto3
import os

client = boto3.client('lambda')

def lambda_handler(event, context):
    inputForInvoke = {'CustomerId': '123', 'Amount': 50 }
    lambdaARN = os.environ('lambda_to_invoker_arn')
    
    response = client.invoke(
        FunctionName='{lambdaARN}',  # name or ARN
        InvocationType='RequestResponse', # Event
        Payload=json.dumps(inputForInvoke)
    )
    
    responseJson = json.load(response['Payload'])
    
    return {
        'statusCode': 200,
        'body': responseJson
    }
    #print('\n')
    #print(responseJson)
    #print('\n')